package com.example.decryptstring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DecryptStringApplicationTests {

    @Test
    void contextLoads() {
    }


}
