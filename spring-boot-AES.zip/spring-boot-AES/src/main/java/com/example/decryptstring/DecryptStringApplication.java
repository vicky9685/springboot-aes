package com.example.decryptstring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DecryptStringApplication {

	public static void main(String[] args) {
		SpringApplication.run(DecryptStringApplication.class, args);
	}

}
